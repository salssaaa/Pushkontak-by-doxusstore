global.d = new Date()
global.calender = d.toLocaleDateString('id')

global.prefix = "." // command prefix
global.ownNumb = "6283133676962" // bot owner // owner name
global.ownName = "𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬" // isi nama kalian
global.ownSc = `𝐊𝐚𝐬𝐭𝐫𝐨𝐥𝐌𝐨𝐝𝐬` //ini gausah di ubah

// GLOBAL MESS - Gausah Di apa²in Tar Eror
global.mess = {
     delay: '2000', // Set Jeda Atur Di sini 1000 = 1 detik
     owner: 'lu siapa?\n*GAUSAH SO ASIK*',
     group: "khusus di dalam Kak",
     inf: "𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 ⚠️\n› sc ini di recode oleh MaulanaMods\n› jangan lupa subs yt saya\n› sc ini di Jual Buy Sc ketik .ownersc\n› happfun your day\n\n𝗥𝗨𝗟𝗘𝗦 𝗣𝗨𝗦𝗛 ‼️\n› minimal push 1 GC isinya 2k member\n  kalo mau di ubah di cofig.js\n› untuk fitur push yg gada set jeda nya\n  gua setting standard [ 2000 ] kalo mau\n  di ubah tinggal cek di file config.js\n›KastrolMods Lagi Open Reseler panel 5k 10 slot*\n\n\n*YT NEW SAYA  :*\n\nhttps://www.youtube.com/@gada\n\n*KastrolMods  :*\n\nwa.me/6283133676962"
}
// BATAS GLOBAL MESS
global.thumb = require('fs').readFileSync("./image/thumb.png")
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log(__filename+' updated!')
	delete require.cache[file]
	require(file)
})

// BASE SCRIPT BY KastrolMods
// NO ENC BISA BUY 
// NO RECONNECT
// JUAL TANPA CREDIT GW? KETAUAN? OTW FULL ENC NO REFF
// MODULE BAILEYS WHISKEY
//SUBSCRIBE YT : https://www.youtube.com/@KastrolMods4
// OWNERSC
// wa.me/+6283133676962